library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity control_unit_tb is
end control_unit_tb;

architecture Behavioral of control_unit_tb is

    -- Component Declaration for the Unit Under Test (UUT)
    component control_unit
    Port ( 
        clk:  in std_logic;
        rst:  in std_logic;
        inst: in std_logic_vector(7 downto 0);
        status: in std_logic_vector(1 downto 0);
        do: out std_logic_vector(21 downto 0);
        lc_zero: in std_logic
    );
    end component;

    -- Clock period definitions
    constant clk_period : time := 10 ns;

    -- Testbench signals
    signal clk : std_logic := '0';
    signal rst : std_logic := '0';
    signal inst : std_logic_vector(7 downto 0) := "00000000";
    signal status : std_logic_vector(1 downto 0) := "00";
    signal do_out : std_logic_vector(21 downto 0);
    signal lc_zero : std_logic := '0';

begin

    -- Instantiate the Unit Under Test (UUT)
    uut: control_unit port map (
        clk => clk,
        rst => rst,
        inst => inst,
        status => status,
        do => do_out,
        lc_zero => lc_zero
    );

    -- Clock process definitions
    clk_process :process
    begin
        while now < 1000 ns loop
            clk <= '0';
            wait for clk_period / 2;
            clk <= '1';
            wait for clk_period / 2;
        end loop;
        wait;
    end process;

    -- Stimulus process
    stim_proc: process
    begin       
        -- Reset simulation inputs
        rst <= '1';
        inst <= "00000000";
        status <= "00";
        lc_zero <= '0';
        wait for clk_period;
        rst <= '0';

        -- Test sequence
        inst <= "00000001"; --LD_ACC
        wait for clk_period * 2;
        
        inst <= "00000010"; --LD_TEMP
        wait for clk_period * 2;
        
        inst <= "00000011"; --ST_ACC1
        wait for clk_period * 2;
        
        inst <= "00000100"; --ST_ACC2
        wait for clk_period * 2;
        
        inst <= "00000101"; --JPF
        wait for clk_period * 2;
        
        inst <= "00000110"; --JPB
        wait for clk_period * 2;
        
        inst <= "00000111"; --JPF_G
        status <= "01"; -- set GT flag
        wait for clk_period * 2;
        
        inst <= "00001000"; --JPF_Z
        status <= "10"; -- set Z flag
        wait for clk_period * 2;
        
        inst <= "00001010"; --ADD
        status <= "00";
        wait for clk_period * 2;

        inst <= "00001001"; --CMP
        status <= "00";
        wait for clk_period * 2;
        
        inst <= "00001011"; --SUB
        status <= "00";
        wait for clk_period * 2;

        inst <= "00001100"; --INC
        status <= "00";
        wait for clk_period * 2;

        end process;

end Behavioral;