library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity acc_entity_tb is
end entity;

architecture behave of acc_entity_tb is
    component acc_entity is
        port (
            clk     : in  std_logic;
            rst     : in  std_logic;
            en      : in  std_logic;
            aen     : in  std_logic;
            data_in : in  std_logic_vector(7 downto 0);
            data_in_alu : in  std_logic_vector(7 downto 0);
            data_out: out std_logic_vector(7 downto 0)
        );
    end component;

    signal clk     : std_logic := '0';
    signal rst     : std_logic := '1';
    signal en      : std_logic := '0';
    signal aen     : std_logic := '0';
    signal data_in : std_logic_vector(7 downto 0) := (others => '0');
    signal data_in_alu : std_logic_vector(7 downto 0) := (others => '0');
    signal data_out: std_logic_vector(7 downto 0) := (others => '0');

begin
    DUT: acc_entity port map (
        clk => clk,
        rst => rst,
        en  => en,
        aen  => aen,
        data_in => data_in,
        data_in_alu => data_in_alu,
        data_out => data_out
    );

    clk_process: process
    begin
        clk <= '0';
        wait for 10 ns;
        clk <= '1';
        wait for 10 ns;
    end process clk_process;

    stim_proc: process
    begin
        rst <= '1';
        en <= '0';
        aen <= '0';
        data_in <= "00000000";
        data_in_alu <= "00000000";
        wait for 20 ns;
        rst <= '0';
        wait for 20 ns;
        en <= '1';
        data_in <= "00000001";
        wait for 20 ns;
        en <= '0';
        wait for 20 ns;
        aen <= '1';
        data_in_alu <= "00000010";
        wait for 20 ns;
        aen <= '0';
        wait for 20 ns;
        en <= '1';
        data_in <= "11111111";
        wait for 20 ns;
        en <= '0';
        wait for 20 ns;
        aen <= '1';
        data_in_alu <= "10101010";
        wait for 20 ns;
        aen <= '0';
        wait for 20 ns;
        wait;
    end process stim_proc;

end behave;
