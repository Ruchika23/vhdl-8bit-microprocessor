library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;
use ieee.numeric_std.all;

entity tb_pc is
end entity tb_pc;

architecture testbench of tb_pc is

    -- Component Declaration for the DUT
    component pc
    port (
        clk: in std_logic;
        rst: in std_logic;
        en: in std_logic;
        jpf: in std_logic;
        jpb: in std_logic;
        input: in std_logic_vector(7 downto 0);
        output: out std_logic_vector(7 downto 0)
    );
    end component;

    -- Inputs
    signal clk_sig : std_logic := '0';
    signal rst_sig : std_logic := '0';
    signal en_sig : std_logic := '0';
    signal jpf_sig : std_logic := '0';
    signal jpb_sig : std_logic := '0';
    signal input_sig : std_logic_vector(7 downto 0) := "00000000";

    -- Outputs
    signal output_sig : std_logic_vector(7 downto 0);

    -- Clock period definitions
    constant clk_period : time := 10 ns;

begin

    -- Instantiate the DUT
    uut: pc port map (
        clk => clk_sig,
        rst => rst_sig,
        en => en_sig,
        jpf => jpf_sig,
        jpb => jpb_sig,
        input => input_sig,
        output => output_sig
    );

    -- Clock process
    clk : process
    begin
        while now < 5000 ns loop
            clk_sig <= '0';
            wait for clk_period / 2;
            clk_sig <= '1';
            wait for clk_period / 2;
        end loop;
        wait;
    end process clk;

     -- Stimulus process
    stim : process
    begin
         -- Reset the DUT
        rst_sig <= '1';
        wait for clk_period;
        rst_sig <= '0';
 
         -- Enable the counter
         
         -- Increment the counter for 10 clock cycles
        en_sig <= '1';
        jpf_sig <= '0';
        jpb_sig <= '0';
        --  for i in 0 to 9 loop
        wait for clk_period*10;
        --  end loop;
 
         -- Check the output
        --  assert output = std_logic_vector(to_unsigned(10, 8)) report "Test 1 failed" severity error;
 
         -- Decrement the counter for 5 clock cycles with load
        input_sig <= std_logic_vector(to_unsigned(1, 8));
        en_sig <= '0';
        jpf_sig <= '0';
        jpb_sig <= '1';
        --  for i in 0 to 4 loop
        wait for clk_period * 5;
        --  end loop;
 
         -- Check the output
        --  assert output = std_logic_vector(to_unsigned(15, 8)) report "Test 2 failed" severity error;
 
         -- Increment the counter for 3 clock cycles
        input_sig <= std_logic_vector(to_unsigned(2, 8));
        en_sig <= '0';
        jpf_sig <= '1';
        jpb_sig <= '0';
        --  for i in 0 to 2 loop
        wait for clk_period * 5;
        --  end loop;
 
         -- Check the output
        --  assert output = std_logic_vector(to_unsigned(12, 8)) report "Test 3 failed" severity error;
    end process stim;

end architecture testbench;
