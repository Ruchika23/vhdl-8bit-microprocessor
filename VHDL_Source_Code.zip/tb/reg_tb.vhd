library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity register_entity_tb is
end register_entity_tb;

architecture tb_arch of register_entity_tb is
    component register_entity is
        port (
            clk      : in  std_logic;
            rst      : in  std_logic;
            en       : in  std_logic;
            data_in  : in  std_logic_vector(7 downto 0);
            data_out : out std_logic_vector(7 downto 0)
        );
    end component;

    signal clk      : std_logic := '0';
    signal rst      : std_logic := '0';
    signal en       : std_logic := '0';
    signal data_in  : std_logic_vector(7 downto 0) := (others => '0');
    signal data_out : std_logic_vector(7 downto 0) := (others => '0');

begin

    dut : register_entity
        port map (
            clk      => clk,
            rst      => rst,
            en       => en,
            data_in  => data_in,
            data_out => data_out
        );

    clk_gen : process
    begin
        while true loop
            clk <= not clk;
            wait for 10 ns; -- add a wait statement
        end loop;
    end process;

    stimulus : process
    begin
        -- reset the design
        rst <= '1';
        wait for 20 ns;
        rst <= '0';

        -- test case 1: write data to the register
        en <= '1';
        data_in <= "11001100";
        wait for 10 ns;
        assert data_out = "11001100"
            report "Test case 1 failed" severity error;
        en <= '0';

        -- test case 2: write data to the register with enable low
        en <= '0';
        data_in <= "10101010";
        wait for 10 ns;
        assert data_out = "11001100"
            report "Test case 2 failed" severity error;

        -- test case 3: write data to the register after a reset
        rst <= '1';
        wait for 20 ns;
        rst <= '0';
        en <= '1';
        data_in <= "11110000";
        wait for 10 ns;
        assert data_out = "11110000"
            report "Test case 3 failed" severity error;
        en <= '0';

        -- test case 4: write data to the register with enable low after a reset
        en <= '0';
        data_in <= "00001111";
        wait for 10 ns;
        assert data_out = "11110000"
            report "Test case 4 failed" severity error;

        wait;
    end process;

end tb_arch;
