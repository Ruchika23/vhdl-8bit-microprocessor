library ieee;
use ieee.std_logic_1164.all;

entity ram256x8_tb is
end entity;

architecture sim of ram256x8_tb is
    -- Component declaration
    component ram256x8 is
        port (
            clk     : in  std_logic;
            rst     : in  std_logic;
            oe      : in  std_logic;
            we      : in  std_logic;
            addr_in : in  std_logic_vector(7 downto 0);
            data_in : in  std_logic_vector(7 downto 0);
            data_out: out std_logic_vector(7 downto 0)
        );
    end component;
    
    -- Input signals
    signal clk     : std_logic := '0';
    signal rst     : std_logic := '0';
    signal oe      : std_logic := '0';
    signal we      : std_logic := '0';
    signal addr_in : std_logic_vector(7 downto 0) := (others => '0');
    signal data_in : std_logic_vector(7 downto 0) := (others => '0');
    
    -- Output signals
    signal data_out: std_logic_vector(7 downto 0) := (others => '0');
    
begin
    -- Instantiate the DUT
    dut: ram256x8 port map (
        clk     => clk,
        rst     => rst,
        oe      => oe,
        we      => we,
        addr_in => addr_in,
        data_in => data_in,
        data_out=> data_out
    );

    -- Clock generation
    clk_gen: process
    begin
        while true loop
            clk <= not clk;
            wait for 5 ns;
        end loop;
    end process;
    
    -- Test scenario
    test: process
    begin
        rst <= '0';
        wait for 10 ns;
        
        -- Read the data from the RAM
        oe      <= '1';
        addr_in <= "00000001";
        wait for 10 ns;

        oe      <= '1';
        addr_in <= "00000010";
        wait for 10 ns;
        
        oe      <= '1';
        addr_in <= "00000011";
        wait for 10 ns;

        -- Reset the DUT
        rst <= '1';
        wait for 10 ns;
        rst <= '0';
        wait for 10 ns;
        

        -- Write some data to the RAM
        we      <= '1';
        addr_in <= "00000001";
        data_in <= "10101010";
        wait for 10 ns;
        we      <= '0';
        wait for 10 ns;
        
        -- Read the data from the RAM
        oe      <= '1';
        addr_in <= "00000001";
        wait for 10 ns;
        
        -- Check the data output
        assert data_out = "10101010"
            report "Data read from RAM does not match expected value"
            severity error;
        
        -- Write some more data to the RAM
        we      <= '1';
        addr_in <= "00010010";
        data_in <= "01010101";
        wait for 10 ns;
        we      <= '0';
        wait for 10 ns;
        
        -- Read the data from the RAM again
        oe      <= '1';
        addr_in <= "00010010";
        wait for 10 ns;
        
        -- Check the data output again
        assert data_out = "01010101"
            report "Data read from RAM does not match expected value"
            severity error;
        
        -- Disable output
        oe <= '0';
        
        wait;
    end process;
end architecture;
