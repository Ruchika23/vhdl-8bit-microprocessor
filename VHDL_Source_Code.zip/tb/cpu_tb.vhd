-- Testbench for CPU entity

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_cpu is
end entity;

architecture sim of tb_cpu is

  signal clk_sig : std_logic := '0';
  signal rst_sig : std_logic := '0';
  signal stp_sig : std_logic := '1';
  constant period : time := 20 ns; -- 50MHz = 1/20ns
  signal count : unsigned(31 downto 0) := (others => '0');

  begin
    process
    begin
      wait for period / 2;
      count <= count + 1;
      if count = to_unsigned(249999, 32) then -- 249999 = 50000000 / 2 - 1
          count <= (others => '0');
          clk_sig <= not clk_sig;
      end if;

      end process;

  -- Instantiate the CPU entity
  uut : entity work.cpu
    port map(
      clk => clk_sig,
      rst => rst_sig,
      stp => stp_sig
    );

end architecture;
