library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity loop_counter_tb is
end loop_counter_tb;

architecture behavior of loop_counter_tb is
    component loop_counter is
        port(
            clk     : in    std_logic;
            en      : in    std_logic;
            reset   : in    std_logic;
            ld      : in    std_logic_vector(7 downto 0);
            lc_zero : out   std_logic
        );
    end component;

    signal clk_sig : std_logic := '0';
    signal en_sig  : std_logic := '0';
    signal rst_sig : std_logic := '0';
    signal ld_sig  : std_logic_vector(7 downto 0) := (others => '0');
    signal lcz_sig : std_logic;

begin
    uut: loop_counter port map(clk => clk_sig, en => en_sig, reset => rst_sig, ld => ld_sig, lc_zero => lcz_sig);

    process
    begin
        rst_sig <= '1';
        ld_sig <= "00001000";  -- Initialize ld to 8
        wait for 10 ns;
        rst_sig <= '0';
        wait for 10 ns;
        en_sig <= '1';  -- Enable the counter
        wait for 20 ns;
        assert lcz_sig = '0' report "Error: LC_ZERO is not 0 when counter is not 0" severity error;
        wait for 70 ns;
        assert lcz_sig = '1' report "Error: LC_ZERO is not 1 when counter is 0" severity error;
        wait for 10 ns;
        en_sig <= '0';  -- Disable the counter
        wait for 10 ns;
        assert lcz_sig = '0' report "Error: LC_ZERO is not 0 when counter is disabled" severity error;
        wait;
    end process;

    clk_sig <= not clk_sig after 5 ns;  -- Clock generator

end behavior;

