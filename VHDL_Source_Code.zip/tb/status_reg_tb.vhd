library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;

entity status_reg_tb is
end entity;

architecture testbench of status_reg_tb is

    -- Component declaration for DUT
    component status_reg
        port (
            clk       : in  std_logic;
            rst       : in  std_logic;
            en        : in  std_logic;
            GT        : in  std_logic;
            Z         : in  std_logic;
            data_out  : out std_logic_vector(1 downto 0)
        );
    end component;

    -- Input signals
    signal clk       : std_logic := '0';
    signal rst       : std_logic := '0';
    signal en        : std_logic := '0';
    signal GT        : std_logic := '0';
    signal Z         : std_logic := '0';

    -- Output signals
    signal data_out  : std_logic_vector(1 downto 0);

begin

    -- Instantiate the DUT
    uut : status_reg
        port map (
            clk      => clk,
            rst      => rst,
            en       => en,
            GT       => GT,
            Z        => Z,
            data_out => data_out
        );

    -- Stimulus process
    stim_proc: process
    begin

        -- Reset the DUT
        rst <= '1';
        wait for 10 ns;
        rst <= '0';

        -- Wait for one clock cycle
        wait for 10 ns;

        -- Enable the DUT and set input values
        en <= '1';
        GT <= '1';
        Z  <= '0';

        -- Wait for one clock cycle
        wait for 10 ns;

        -- Check the output
        assert data_out = "01"
            report "Error: Expected data_out to be '01'" severity error;

        -- Set new input values
        GT <= '0';
        Z  <= '1';

        -- Wait for one clock cycle
        wait for 10 ns;

        -- Check the output
        assert data_out = "10"
            report "Error: Expected data_out to be '10'" severity error;

        -- Disable the DUT
        en <= '0';

        -- Wait for one clock cycle
        wait for 10 ns;

        -- Check the output
        assert data_out = "00"
            report "Error: Expected data_out to be '00'" severity error;

        -- End the simulation
        wait;
    end process;

    -- Clock generator process
    clk_proc: process
    begin
        while true loop
            clk <= not clk;
            wait for 5 ns;
        end loop;
    end process;

end testbench;
