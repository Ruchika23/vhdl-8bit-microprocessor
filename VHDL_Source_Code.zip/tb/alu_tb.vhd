library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;

entity alu_tb is
	end entity;
	
	architecture behave of alu_tb is
		-- Declare the signals used in the testbench
		signal en        : std_logic := '1';
		signal op        : std_logic_vector(1 downto 0) := "00";
		signal reg_a_in  : std_logic_vector(7 downto 0) := (others => '0');
		signal reg_b_in  : std_logic_vector(7 downto 0) := (others => '0');
		signal carry_out : std_logic;
		signal GT        : std_logic;
		signal Z         : std_logic;
		signal res_out   : std_logic_vector(7 downto 0);
	
		-- Instantiate the ALU entity
		component alu
			port (
				en        : in  std_logic;
				op        : in  std_logic_vector(1 downto 0);
				reg_a_in  : in  std_logic_vector(7 downto 0);
				reg_b_in  : in  std_logic_vector(7 downto 0);
				carry_out : out std_logic;
				GT        : out std_logic;
				Z         : out std_logic;
				res_out   : out std_logic_vector(7 downto 0)
			);
		end component;
		
	begin
		-- Instantiate the DUT (Device Under Test)
		DUT : alu
			port map (
				en        => en,
				op        => op,
				reg_a_in  => reg_a_in,
				reg_b_in  => reg_b_in,
				carry_out => carry_out,
				GT        => GT,
				Z         => Z,
				res_out   => res_out
			);
			
		-- Stimulus process
		process
		begin
			-- Test ADD operation
			op <= "00";
			reg_a_in <= "00010001";
			reg_b_in <= "00001010";
			wait for 10 ns;
			
			-- Test SUB operation
			op <= "11";
			reg_a_in <= "00010001";
			reg_b_in <= "00001010";
			wait for 10 ns;
			
			-- Test CMP operation
			op <= "10";
			reg_a_in <= "00010001";
			reg_b_in <= "00001010";
			wait for 10 ns;
			
			-- Test CMP operation
			op <= "10";
			reg_a_in <= "00001010";
			reg_b_in <= "00010001";
			wait for 10 ns;

			-- Test INC operation
			op <= "01";
			reg_a_in <= "00010001";
			wait for 10 ns;
			
			-- Test invalid operation
			op <= "10"; -- invalid operation
			reg_a_in <= "00010001";
			reg_b_in <= "00001010";
			wait for 10 ns;
			
			wait;
		end process;
		
	end behave;
	