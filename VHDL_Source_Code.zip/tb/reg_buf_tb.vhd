library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;

entity register_buffer_tb is
end entity register_buffer_tb;

architecture behave of register_buffer_tb is

    component register_buffer is
        port (
            reg_out : in std_logic_vector(7 downto 0);
            data_out : inout std_logic_vector(7 downto 0);
            oe : in std_logic
        );
    end component;

    signal reg_out : std_logic_vector(7 downto 0) := "00000000";
    signal data_out : std_logic_vector(7 downto 0) := "ZZZZZZZZ";
    signal oe : std_logic := '1';

begin

    UUT: register_buffer port map (
        reg_out => reg_out,
        data_out => data_out,
        oe => oe
    );

    -- Stimulus process
    stimulus: process
    begin
        -- Enable buffer
        oe <= '0';
        reg_out <= "10101010";
        wait for 10 ns;
        
        -- Disable buffer
        oe <= '1';
        wait for 10 ns;
        
        -- Enable buffer again
        oe <= '0';
        reg_out <= "01010101";
        wait for 10 ns;
        
        -- Disable buffer again
        oe <= '1';
        wait for 10 ns;
        
        -- End simulation
        wait;
    end process stimulus;

end behave;
