library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity acc_buf_tb is
end entity;

architecture behave of acc_buf_tb is
    component acc_buf is
        port (
            reg_out : in std_logic_vector(7 downto 0);
            data_out : out std_logic_vector(7 downto 0);
            data_out_alu : out std_logic_vector(7 downto 0);
            oe : in std_logic
        );
    end component;

    signal reg_out : std_logic_vector(7 downto 0);
    signal data_out : std_logic_vector(7 downto 0);
    signal data_out_alu : std_logic_vector(7 downto 0);
    signal oe : std_logic := '0';

begin
    DUT: acc_buf port map (
        reg_out => reg_out,
        data_out => data_out,
        data_out_alu => data_out_alu,
        oe => oe
    );

    stim_proc: process
    begin
        reg_out <= "00000000";
        oe <= '1';
        wait for 10 ns;

        reg_out <= "11111111";
        wait for 10 ns;

        oe <= '0';
        wait for 10 ns;

        reg_out <= "01010101";
        oe <= '1';
        wait for 10 ns;

        reg_out <= "ZZZZZZZZ";
        wait for 10 ns;

        reg_out <= "10101010";
        wait for 10 ns;

        oe <= '0';
        wait for 10 ns;

        reg_out <= "00001111";
        oe <= '1';
        wait for 10 ns;

        wait;
    end process stim_proc;

end behave;
