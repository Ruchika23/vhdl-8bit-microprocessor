library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;


entity status_reg is
    port (
        clk       : in  std_logic;
        rst       : in  std_logic;
        en        : in  std_logic;
        GT        : in  std_logic;
        Z         : in  std_logic;
        data_out  : out std_logic_vector(1 downto 0)
    );
end entity;

architecture behave of status_reg is

    signal stored_value : std_logic_vector(1 downto 0) := (others => '0');

begin

    process (clk, rst)
    begin
        if rst = '1' then
            stored_value <= (others => '0');
        elsif rising_edge(clk) then
            if en = '1' then
                stored_value(0) <= GT;
                stored_value(1) <= Z;
            end if;
        end if;
    end process;

    data_out <= stored_value;

end behave;