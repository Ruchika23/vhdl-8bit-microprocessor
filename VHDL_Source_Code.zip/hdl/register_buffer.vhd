library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;

entity register_buffer is
    port (
        reg_out : in std_logic_vector(7 downto 0);
        data_out : inout std_logic_vector(7 downto 0);
        oe : in std_logic
    );
end entity;

architecture behave of register_buffer is
    signal reg_buf : std_logic_vector(7 downto 0);
begin
    reg_buf <= reg_out;

    data_out <= "ZZZZZZZZ" when oe = '0' else reg_buf;

    buffer_enable: process(oe, reg_buf)
    begin
        if oe = '0' then
            data_out <= "ZZZZZZZZ";
        elsif reg_buf /= "ZZZZZZZZ" then
            data_out <= reg_buf;
        end if;
    end process buffer_enable;
end behave;
