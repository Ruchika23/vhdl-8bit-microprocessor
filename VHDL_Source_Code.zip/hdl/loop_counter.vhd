library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;

entity loop_counter is
    port(
        clk     : in    std_logic;
        en      : in    std_logic;
        reset   : in    std_logic;
        ld      : in    std_logic_vector(7 downto 0);  -- Number of loop iterations
        lc_zero : out   std_logic                  -- Indicates when the loop is complete
    );
end loop_counter;

architecture behavior of loop_counter is
    signal cnt : std_logic_vector(7 downto 0);

begin
    process(clk, reset)
    begin
        if reset = '1' then
            cnt <= ld;                   -- Initialize counter to ld
            lc_zero <= '0';             -- Clear LC_ZERO signal
        elsif rising_edge(clk) then
            if en = '1' then
                if cnt = "00000000" then
                    cnt <= ld;           -- Reset counter when it reaches 0
                    lc_zero <= '1';     -- Set LC_ZERO signal
                else
                    cnt <= cnt - 1;     -- Decrement counter
                    lc_zero <= '0';     -- Clear LC_ZERO signal
                end if;
            else
                lc_zero <= '0';         -- Clear LC_ZERO signal if en is not enabled
            end if;
        end if;
    end process;

end behavior;

