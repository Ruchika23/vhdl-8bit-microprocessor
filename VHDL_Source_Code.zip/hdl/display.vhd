library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_unsigned.all;

-- Hex Display module
entity HexDisplay is
    port (
        en : in std_logic;
        input_data : in std_logic_vector(7 downto 0);
        seg1 : out std_logic_vector(6 downto 0);
        seg2 : out std_logic_vector(6 downto 0)
    );
end HexDisplay;

architecture Behavioral of HexDisplay is
    -- Define mapping of input data to 7-segment display segments
    function segment_map(input : std_logic_vector(3 downto 0)) return std_logic_vector is
    begin
        case input is
            when "0000" => return "0000001"; -- 0
            when "0001" => return "1001111"; -- 1
            when "0010" => return "0010010"; -- 2
            when "0011" => return "0000110"; -- 3
            when "0100" => return "1001100"; -- 4
            when "0101" => return "0100100"; -- 5
            when "0110" => return "0100000"; -- 6
            when "0111" => return "0001111"; -- 7
            when "1000" => return "0000000"; -- 8
            when "1001" => return "0000100"; -- 9
            when "1010" => return "0001000"; -- A
            when "1011" => return "1100000"; -- b
            when "1100" => return "0110001"; -- C
            when "1101" => return "1000010"; -- d
            when "1110" => return "0110000"; -- E
            when "1111" => return "0111000"; -- F
            when others => return "1111111"; -- Blank
        end case;
    end function;
    -- Define signals for input data and segment values
    signal input_data1 : std_logic_vector(3 downto 0);
    signal input_data2 : std_logic_vector(3 downto 0);
    signal seg1_value : std_logic_vector(6 downto 0);
    signal seg2_value : std_logic_vector(6 downto 0);

begin

    -- Split input data into two 4-bit values
    input_data1 <= input_data(7 downto 4);
    input_data2 <= input_data(3 downto 0);

    -- Map input data to 7-segment display segments using function
    seg1_value <= segment_map(input_data1);
    seg2_value <= segment_map(input_data2);

    -- Assign segment values to outputs
    seg1 <= seg1_value;
    seg2 <= seg2_value;
end Behavioral;
