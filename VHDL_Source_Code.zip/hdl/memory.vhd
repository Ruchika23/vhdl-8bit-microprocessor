library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library std;
use std.textio.all;

entity ram256x8 is
    port (
        clk     : in  std_logic;     -- clock
        rst     : in  std_logic;     -- reset
        oe      : in  std_logic;     -- output enable
        we      : in  std_logic;     -- write enable
        addr_in : in  std_logic_vector(7 downto 0);  -- address input
        data_in : in  std_logic_vector(7 downto 0);  -- data input
        data_out: out std_logic_vector(7 downto 0)   -- data output
    );
end entity;

architecture rtl of ram256x8 is
    
    --Addition Program
    type mem_type is array (0 to 15) of std_logic_vector(7 downto 0);
    signal memory : mem_type := (
        ---Program Block---
        x"81",           -- (0) LD_ADR1 [for B]
        x"0B",           -- (1) LD_ADR1 Parameter [address of B]
        x"82",           -- (2) LD_ADR2 [for C]
        x"0E",           -- (3) LD_ADR2 Parameter [address of C]
        x"01",           -- (4) LD_ACC  Load A from ADR1
        x"02",           -- (5) LD_TEMP Load B from ADR2
        x"0A",           -- (6) ADD value in TEMP and ACC
        x"81",           -- (7) LD_ADR1 [for A]
        x"0F",           -- (8) LD_ADR1 Parameter [address of A]
        x"03",           -- (9) ST_ACC1 Store B+C (ACC value) to address of A
        x"FF",           -- (10) HALT
        ---Non-Program Block---
        x"45",           -- (11) B
        x"00",           -- (12)
        x"00",           -- (13) 
        x"32",           -- (14) C
        x"00"            -- (15) A
    );

    --Comparison Program
    -- type mem_type is array (0 to 21) of std_logic_vector(7 downto 0);
    -- signal memory : mem_type := (
    --     ---Program Block---
    --     x"81",           -- (0) LD_ADR1 [for A]
    --     x"11",           -- (1) LD_ADR1 Parameter [address of A]
    --     x"01",           -- (2) LD_ACC Load A from ADR1
    --     x"85",           -- (3) LD_CONST2 
    --     x"00",           -- (4) LD_CONST2 Parameter [constant 0]
    --     x"83",           -- (5) LD_JUMPREG
    --     x"06",           -- (6) LD_JUMPREG Parameter
    --     x"09",           -- (7) CMP
    --     x"07",           -- (8) JPF_G
    --     x"81",           -- (9) LD_ADR1 [for C]
    --     x"14",           -- (10) LD_ADR1 Parameter [address of C]
    --     x"01",           -- (11) LD_ACC  Load C from ADR1
    --     x"81",           -- (12) LD_ADR1 [for B]
    --     x"13",           -- (13) LD_ADR1 Parameter [address of B]
    --     x"03",           -- (14) ST_ACC1 Store C to the address of B
    --     x"FF",           -- (15) HALT
        
    --     ---Non-Program Block---
    --     x"00",           -- (16)
    --     x"45",           -- (17) A
    --     x"00",           -- (18)
    --     x"00",           -- (19) B
    --     x"32",           -- (20) C
    --     x"00"            -- (21) 
    -- );

    


begin


    process(clk, rst)
    begin
        if rst = '1' then
            memory <= (others => (others => '0'));
        elsif rising_edge(clk) then
            if oe = '1' then
                data_out <= memory(to_integer(unsigned(addr_in)));
                report to_string(memory(to_integer(unsigned(addr_in))));
            elsif we = '1' then
                memory(to_integer(unsigned(addr_in))) <= data_in;
                report to_string(data_in);
            else
                data_out <= "ZZZZZZZZ";
            end if;
        end if;
    end process;
end architecture;
