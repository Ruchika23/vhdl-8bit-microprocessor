library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;


entity cpu is 
	port(
		clk : in std_logic;
		rst : in std_logic;
		stp : in std_logic
	);
end entity;



architecture behave of cpu is

component pc is 
	port(
		clk : in std_logic;
		rst	: in std_logic;
		en 	: in std_logic;
		jpf	: in std_logic;
		jpb	: in std_logic;
		input: in std_logic_vector(7 downto 0);
		output: out std_logic_vector(7 downto 0)
	);
end component;

component loop_counter is
    port(
        clk     : in    std_logic;
        en      : in    std_logic;
        reset   : in    std_logic;
        ld      : in    std_logic_vector(7 downto 0); 
        lc_zero : out   std_logic
    );
end component;

component register_entity is
    port (
        clk      : in  std_logic;
        rst      : in  std_logic;
        en    	 : in  std_logic;
        data_in  : in  std_logic_vector(7 downto 0);
        data_out : out std_logic_vector(7 downto 0)
    );
end component;

component alu is
    port (
        en        : in  std_logic;
        op        : in  std_logic_vector(1 downto 0);
        reg_a_in  : in  std_logic_vector(7 downto 0);
        reg_b_in  : in  std_logic_vector(7 downto 0);
        carry_out : out std_logic;
        GT : out std_logic;
        Z : out std_logic;
        res_out   : out std_logic_vector(7 downto 0)
    );
end component;

component register_buffer is
    port (
        reg_out : in std_logic_vector(7 downto 0);
        data_out : inout std_logic_vector(7 downto 0);
        oe : in std_logic
    );
end component;

component ram256x8 is
    port (
        clk     : in  std_logic;     -- clock
        rst     : in  std_logic;     -- reset
        oe      : in  std_logic;     -- output enable
        we      : in  std_logic;     -- write enable
        addr_in : in  std_logic_vector(7 downto 0);  -- address input
        data_in : in  std_logic_vector(7 downto 0);  -- data input
        data_out: out std_logic_vector(7 downto 0)   -- data output
    );
end component;

component control_unit is
	port ( 
		clk: in std_logic;
		rst: in std_logic;
		inst: in std_logic_vector(7 downto 0);
		status: in std_logic_vector(1 downto 0); -- GT -- Z
		do : out std_logic_vector(21 downto 0);
		lc_zero: in std_logic
	);
end component;

component status_reg is
    port (
        clk       : in  std_logic;
        rst     : in  std_logic;
        en    : in  std_logic;
        GT        : in  std_logic;
        Z         : in  std_logic;
        data_out  : out std_logic_vector(1 downto 0)
    );
end component;

component HexDisplay is
    port (
		en: in std_logic;
        input_data : in std_logic_vector(7 downto 0);
        seg1 : out std_logic_vector(6 downto 0);
        seg2 : out std_logic_vector(6 downto 0)
    );
end component;

component acc_buf is
    port (
        reg_out : in std_logic_vector(7 downto 0);
        data_out : out std_logic_vector(7 downto 0);
        data_out_alu : out std_logic_vector(7 downto 0);
        oe : in std_logic
    );
end component;

component acc_entity is
    port (
        clk     : in  std_logic;
        rst     : in  std_logic;
        en      : in  std_logic;
        aen      : in  std_logic;
        data_in   : in  std_logic_vector(7 downto 0);
        data_in_alu   : in  std_logic_vector(7 downto 0);
        data_out  : out std_logic_vector(7 downto 0)
    );
end component;

signal main_bus: std_logic_vector(7 downto 0);
signal addr_bus: std_logic_vector(7 downto 0);

signal clk_sig : std_logic;
signal inv_clk_sig : std_logic;

signal cu_out_sig: std_logic_vector(21 downto 0);


signal halt_sig : std_logic;
signal mem_oe_sig: std_logic;
signal mem_we_sig: std_logic;

signal pc_op_sig:std_logic_vector(7 downto 0);
signal pc_in_sig:std_logic_vector(7 downto 0);
signal pc_en_sig:std_logic;
signal pc_oe_sig:std_logic;
signal pc_jpf_sig:std_logic;
signal pc_jpb_sig:std_logic;
signal jump_reg_en_sig:std_logic;
signal adr1_en_sig:std_logic;
signal adr1_buf_oe_sig:std_logic;
signal adr1_out_sig:std_logic_vector(7 downto 0);
signal adr2_en_sig:std_logic;
signal adr2_buf_oe_sig:std_logic;
signal adr2_out_sig:std_logic_vector(7 downto 0);
signal acc_en_sig:std_logic;
signal acc_buf_oe_sig:std_logic;
signal acc_out_sig:std_logic_vector(7 downto 0);
signal temp_en_sig:std_logic;

signal alu_en_sig:std_logic;
signal alu_op_sig:std_logic_vector(1 downto 0);
signal alu_reg_a_in_sig:std_logic_vector(7 downto 0);
signal alu_reg_b_in_sig:std_logic_vector(7 downto 0);
signal alu_carry_out_sig:std_logic;
signal alu_GT_sig:std_logic;
signal alu_Z_sig:std_logic;
signal alu_res_out_sig:std_logic_vector(7 downto 0);

signal stat_reg_en_sig:std_logic;
signal status_reg_out_sig:std_logic_vector(1 downto 0);
signal inst_en_sig:std_logic;
signal inst_out_sig:std_logic_vector(7 downto 0);

signal lc_zero_sig:std_logic;
signal lc_en_sig:std_logic;


begin

pc_inst : pc port map (
	clk	=>	clk_sig,
	rst	=>	rst,
	en 	=>	pc_en_sig,	
	jpf =>	pc_jpf_sig,
	jpb	=>	pc_jpb_sig,
	input => pc_in_sig,
	output=> pc_op_sig
);

pc_buf_inst : register_buffer port map (
	reg_out => pc_op_sig,
	data_out => addr_bus,
	oe => pc_oe_sig
);

jump_reg_inst : register_entity port map (
	clk     => clk_sig,
	rst     => rst,
	en      => jump_reg_en_sig,
	data_in   => main_bus,
	data_out  => pc_in_sig
);

adr1_inst : register_entity port map (
	clk     => clk_sig,
	rst     => rst,
	en      => adr1_en_sig,
	data_in   => main_bus,
	data_out  => adr1_out_sig
);

adr1_buf_inst : register_buffer port map (
	reg_out  => adr1_out_sig,
	data_out => addr_bus,
	oe => adr1_buf_oe_sig
);

adr2_inst : register_entity port map (
	clk     => clk_sig,
	rst     => rst,
	en      => adr2_en_sig,
	data_in   => main_bus,
	data_out  => adr2_out_sig
);

adr2_buf_inst : register_buffer port map (
	reg_out  => adr2_out_sig,
	data_out => addr_bus,
	oe => adr2_buf_oe_sig
);

acc_inst : acc_entity port map (
	clk     => clk_sig,
	rst     => rst,
	en      => acc_en_sig,
	aen 	=> alu_en_sig,
	data_in		=> main_bus,
	data_in_alu => alu_res_out_sig,
	data_out 	=> acc_out_sig
);

acc_buf_inst : acc_buf port map (
	reg_out  => acc_out_sig,
	data_out => main_bus,
	data_out_alu => alu_reg_a_in_sig,
	oe => acc_buf_oe_sig
);

temp_inst : register_entity port map (
	clk     => clk_sig,
	rst     => rst,
	en      => temp_en_sig,
	data_in   => main_bus,
	data_out  => alu_reg_b_in_sig
);

alu_inst : alu port map (
	en        => alu_en_sig,
	op        => alu_op_sig, --
	reg_a_in  => alu_reg_a_in_sig,
	reg_b_in  => alu_reg_b_in_sig,
	carry_out => alu_carry_out_sig, --
	GT		  => alu_GT_sig,
	Z 		  => alu_Z_sig,
	res_out   => alu_res_out_sig
);


status_reg_inst : status_reg port map (
	clk       => clk_sig,
	rst       => rst,
	en        => stat_reg_en_sig,
	GT        => alu_GT_sig,
	Z         => alu_Z_sig,
	data_out  => status_reg_out_sig
);


control_unit_inst : control_unit port map (
	clk  => inv_clk_sig,
	rst  => rst,
	inst => inst_out_sig,
	status => status_reg_out_sig,
	do => cu_out_sig,
	lc_zero => lc_zero_sig
);


instr_reg_inst : register_entity port map (
	clk     => clk_sig,
	rst     => rst,
	en      => inst_en_sig,
	data_in   => main_bus,
	data_out  => inst_out_sig
);

ram_inst: ram256x8 port map (
	clk	=> clk_sig,
	rst	=> rst,
	oe	=> mem_oe_sig,
	we	=> mem_we_sig,
	addr_in	 => addr_bus,
	data_in	 => main_bus,
	data_out => main_bus
);

lc_inst: loop_counter port map (
	clk		=> clk_sig,
	en		=> lc_en_sig,
	reset	=> rst,
	ld		=> main_bus,
	lc_zero	=> lc_zero_sig
);

hex_addr_inst: HexDisplay port map (
	en => stp,
	input_data => addr_bus
);


hex_data_inst: HexDisplay port map (
	en => stp,
	input_data => main_bus
);

clk_sig <= clk and (not halt_sig);
inv_clk_sig <= not clk_sig;


alu_op_sig	<= cu_out_sig(21 downto 20);
alu_en_sig	<= cu_out_sig(19);
lc_en_sig 	<= cu_out_sig(18);
mem_oe_sig	<= cu_out_sig(17);
mem_we_sig	<= cu_out_sig(16);
pc_jpf_sig	<= cu_out_sig(15);
pc_jpb_sig	<= cu_out_sig(14);
pc_en_sig 	<= cu_out_sig(13);
pc_oe_sig 	<= cu_out_sig(12);
adr1_en_sig	 	<= cu_out_sig(11);
adr1_buf_oe_sig <= cu_out_sig(10);
adr2_en_sig		<= cu_out_sig(9);
adr2_buf_oe_sig	<= cu_out_sig(8);
jump_reg_en_sig <= cu_out_sig(7);
temp_en_sig 	<= cu_out_sig(6);
acc_en_sig		<= cu_out_sig(5);
acc_buf_oe_sig	<= cu_out_sig(4);
stat_reg_en_sig <= cu_out_sig(3);
inst_en_sig 	<= cu_out_sig(2);
halt_sig 		<= cu_out_sig(0);

end behave;