library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;


entity alu is
    port (
        en        : in  std_logic;
        op        : in  std_logic_vector(1 downto 0);
        reg_a_in  : in  std_logic_vector(7 downto 0);
        reg_b_in  : in  std_logic_vector(7 downto 0);
        carry_out : out std_logic;
        GT : out std_logic;
        Z : out std_logic;
        res_out   : out std_logic_vector(7 downto 0)
    );
end entity;

architecture behave of alu is 

    signal result : std_logic_vector(8 downto 0);
    signal GT_sig : std_logic := 'Z';
    signal Z_sig  : std_logic := 'Z';

begin

    process(reg_a_in,reg_b_in,op)
    begin
        case op is
            when "00" => -- ADD operation
                result <= ext(reg_a_in,9) + ext(reg_b_in,9);
				carry_out <= result(8);
            when "11" => -- SUB operation
                result <= ext(reg_a_in,9) - ext(reg_b_in,9);
				carry_out <= result(8);
            when "10" => -- CMP operation
                if reg_a_in < reg_b_in then -- A less than (R/M)
                    GT_sig <= '1';
                    Z_sig <= '0';
                elsif reg_a_in = reg_b_in then -- A equals to (R/M)
                    GT_sig <= '0';
                    Z_sig <= '1';
                elsif reg_a_in > reg_b_in then-- A greater than (R/M)
                    GT_sig <= '0';
                    Z_sig <= '0';
                end if;
                result <= (others => '0');
            when "01" => --INC operation
                result <= ext(reg_a_in,9) + ext("00000001",9);
            when others => -- Invalid operation
                result <= (others => 'X');
        end case;
    end process;
	GT <= GT_sig;
    Z <= Z_sig;
    res_out   <= result(7 downto 0) when en = '1' else (others => 'Z');
    
	
end behave;
