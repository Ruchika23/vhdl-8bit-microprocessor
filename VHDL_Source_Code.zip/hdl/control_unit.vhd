library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

use IEEE.STD_LOGIC_UNSIGNED.ALL;


entity control_unit is
Port ( 
    clk:  in std_logic;
    rst:  in std_logic;
    inst: in std_logic_vector(7 downto 0);
    status: in std_logic_vector(1 downto 0); -- GT -- Z
    do: out std_logic_vector(21 downto 0);
    lc_zero: in std_logic
);
end control_unit;

architecture Behavioral of control_unit is

signal counter: std_logic_vector(1 downto 0):="11";
begin

count_proc:process(clk,rst)

begin

if rst='1' then
    counter<="00";
elsif rising_edge(clk) then
    if(counter = "11")then
        counter<="00";
    else
        counter <= std_logic_vector(unsigned(counter)+1);
    end if;
    
end if;
end process;


do <= "0000100001000000000000" when counter = "00" else
      "0000000010000000000100" when counter = "01" else 
      
      --10000001 LD_ADR1
      "0000100001000000000000" when (counter = "10" and inst="10000001") else
      "0000000010100000000000" when (counter = "11" and inst="10000001") else

      --10000010 LD_ADR2
      "0000100001000000000000" when (counter = "10" and inst="10000010") else
      "0000000010001000000000" when (counter = "11" and inst="10000010") else

      --10000011 LD_JUMPREG
      "0000100001000000000000" when (counter = "10" and inst="10000011") else
      "0000000010000010000000" when (counter = "11" and inst="10000011") else

      --10000100 LD_CONST1
      "0000100001000000000000" when (counter = "10" and inst="10000100") else
      "0000000010000000100000" when (counter = "11" and inst="10000100") else

      --10000101 LD_CONST2
      "0000100001000000000000" when (counter = "10" and inst="10000101") else
      "0000000010000001000000" when (counter = "11" and inst="10000101") else

      --00000001 LD_ACC
      "0000100000010000000000" when (counter = "10" and inst="00000001") else
      "0000000000000000100000" when (counter = "11" and inst="00000001") else

      --00000010 LD_TEMP
      "0000100000000100000000" when (counter = "10" and inst="00000010") else
      "0000000000000001000000" when (counter = "11" and inst="00000010") else

      --00000011 ST_ACC1
      "0000010000010000010000" when (counter = "10" and inst="00000011") else
      "0000000000000000000000" when (counter = "11" and inst="00000011") else

      --00000100 ST_ACC2
      "0000010000000100010000" when (counter = "10" and inst="00000100") else
      "0000000000000000000000" when (counter = "11" and inst="00000100") else

      --00000101 JPF
      "0000001000000000000000" when (counter = "10" and inst="00000101") else
      "0000000000000000000000" when (counter = "11" and inst="00000101") else

      --00000110 JPB
      "0000000100000000000000" when (counter = "10" and inst="00000110") else
      "0000000000000000000000" when (counter = "11" and inst="00000110") else

      --00000111 JPF_G
      "0000001000000000000000" when (counter = "10" and inst="00000111" and status(0)='1') else
      "0000000000000000000000" when (counter = "11" and inst="00000111" and status(0)='1') else

      --00001000 JPF_Z
      "0000001000000000000000" when (counter = "10" and inst="00001000" and status(1)='1') else
      "0000000000000000000000" when (counter = "11" and inst="00001000" and status(1)='1') else

      --00001001 CMP
      "1000000000000000010000" when (counter = "10" and inst="00001001") else
      "0000000000000000001000" when (counter = "11" and inst="00001001") else

      --00001010 ADD
      "0000000000000000010000" when (counter = "10" and inst="00001010") else
      "0010000000000000010000" when (counter = "11" and inst="00001010") else
      
      --00001011 SUB
      "1100000000000000010000" when (counter = "10" and inst="00001011") else
      "1110000000000000000000" when (counter = "11" and inst="00001011") else
      
      --00001100 INC
      "0100000000000000010000" when (counter = "10" and inst="00001100") else
      "0110000000000000000000" when (counter = "11" and inst="00001100") else

      --11111111 HALT
      "0000000000000000000001" when (counter = "10" and inst="11111111") else
      "0000000000000000000001" when (counter = "11" and inst="11111111") else

      --DEFAULT
      "0000000000000000000000" when (counter = "10") else
      "0000000000000000000000" when (counter = "11");

end Behavioral;